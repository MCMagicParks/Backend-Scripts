__title__     = 'LAPS4LINUX'
__author__    = 'Georg Sieber'
__copyright__ = '© 2021-2024'
__license__   = 'GPL-3.0'
__version__   = '1.11.4'
__website__   = 'https://github.com/schorschii/LAPS4LINUX'

__all__ = [__author__, __license__, __version__]
